# SoftoAI  Twój partner w nowoczesnym świecie

# Skontaktuj się z nami

## Formularz kontaktowy

Imię i nazwisko

Adres e-mail

Wiadomość

Wyślij wiadomość


## Nasze dane kontaktowe

Jeśli wolisz tradycyjną formę kontaktu, możesz skorzystać z poniższych danych:


- Adres: ul. Królewska 3/4, 86-301 Grudziądz
- E-mail: kontakt@softoai.whatever
- Telefon: +48 (22) 62 15 035

### Godziny pracy:

Poniedziałek - Piątek: 9:00 - 17:00

Sobota: 10:00 - 14:00