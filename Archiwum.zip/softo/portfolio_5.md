# SoftoAI  Twój partner w nowoczesnym świecie

{{FLG:THATWASSHE}}

Z zeznań świadków wynika, że jedna z kobiet mieszkających w Saskiej Kępie mogła mieć kontakt z poszukiwanym przez nas profesorem Majem. Udało nam się dostać do [nagrania z jej zeznań](https://youtu.be/TjRpORufCpg?si=wpHro7cNj_82xLpX&t=17), gdzie twierdzi, że na pewno był to profesor.

[« Wróć do listy klientów](https://softo.ag3nts.org/portfolio)